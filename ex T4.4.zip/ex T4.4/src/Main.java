public class Main {
    public static void main(String[] args) {
       for (int contador = 0; contador <= 3; contador = contador + 1) {
           System.out.println(contador);
       }
    }
}