public class Main {
    public static void main(String[] args) {
        //Crea un bucle While, este bucle tendrá que tener como condición que la variable numeroWhile sea inferior a 3, el bloque de código que tendrá el bucle deberá:
        //Incrementar el valor de la variable en uno cada vez que se ejecute.
        // Mostrarlo por pantalla cada vez que se ejecute.
        int contador = 1;
        while (contador <= 3) {
            System.out.println(contador);
            contador = contador + 1;
        }
    }
}