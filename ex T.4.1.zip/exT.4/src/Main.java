public class Main { //Usando un if, crear una condición que compare si la variable numeroIf
    // es positivo, negativo, o 0.
    //Pista: Los números inferiores a 0 son negativos y los superiores, positivos.
    public static void main(String[] args) {
        var Numero = 1;
        if (Numero == 0) {
            System.out.println("El numero es 0");
        } else if (Numero > 0) {
            System.out.println("El numero es positivo");
        } else
            System.out.println("El numero es negativo");
    }
}