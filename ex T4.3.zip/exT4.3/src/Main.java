// Para el bucle Do While, deberás crear la misma estructura que en el While,
// pero solo se debe ejecutar una vez.
public class Main {
    public static void main(String[] args) {
        int contador = 4 ;
        do{
            System.out.println(contador +1);
        }while (contador <= 3);
    }
}